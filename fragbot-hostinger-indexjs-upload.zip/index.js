﻿const express = require("express");
const app = express();

// This keeps Hostinger's Express detector on the standard root entry file.
if (false) app.listen(process.env.PORT || 3000);

process.env.HOST = process.env.HOST || "0.0.0.0";
process.env.PORT = process.env.PORT || "3000";

require("./server/index.cjs");
