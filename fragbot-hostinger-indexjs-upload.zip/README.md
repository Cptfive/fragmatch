﻿# FRAGBOT Hostinger Upload

Use this package for Hostinger Node.js Web App upload.

Settings:
- Framework: Express.js
- Build command: npm run build
- Start command: npm start
- Entry file: index.js
- Output directory: dist
- Root directory: .

No secrets are included. Add environment variables in Hostinger from HOSTINGER_ENV_VARIABLES_TEMPLATE.env.
