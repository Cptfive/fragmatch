// server/index.ts
import cors from "cors";
import express from "express";
import { nanoid as nanoid5 } from "nanoid";
import path2 from "node:path";
import { fileURLToPath } from "node:url";
import Stripe from "stripe";
import { z } from "zod";

// server/env.ts
import dotenv from "dotenv";
dotenv.config({ path: ".env.local" });
dotenv.config();
var env = {
  port: Number(process.env.PORT ?? 3001),
  host: process.env.HOST ?? "0.0.0.0",
  clientUrl: process.env.CLIENT_URL ?? "https://fragbot.tech",
  blazeClientId: process.env.BLAZE_CLIENT_ID ?? "",
  blazeClientSecret: process.env.BLAZE_CLIENT_SECRET ?? "",
  blazeBotAccount: process.env.BLAZE_BOT_ACCOUNT ?? "fragbot",
  blazeBotLoginUsername: process.env.BLAZE_BOT_LOGIN_USERNAME ?? "",
  blazeBotLoginPassword: process.env.BLAZE_BOT_LOGIN_PASSWORD ?? "",
  fragbotAdminToken: process.env.FRAGBOT_ADMIN_TOKEN ?? "",
  blazeRedirectUri: process.env.BLAZE_REDIRECT_URI ?? "https://fragbot.tech/api/blaze/callback",
  openAiApiKey: process.env.OPENAI_API_KEY ?? "",
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? "",
  stripeProPriceId: process.env.STRIPE_PRO_PRICE_ID ?? "",
  stripePaymentLinkUrl: process.env.STRIPE_PAYMENT_LINK_URL ?? ""
};
function safeConnectionStatus(listenerRunning) {
  return {
    hasBlazeClientId: Boolean(env.blazeClientId),
    hasBlazeClientSecret: Boolean(env.blazeClientSecret),
    hasBotLoginCredentials: Boolean(env.blazeBotLoginUsername && env.blazeBotLoginPassword),
    hasOpenAiKey: Boolean(env.openAiApiKey),
    hasStripeSecretKey: Boolean(env.stripeSecretKey),
    hasStripeCheckout: Boolean(env.stripeSecretKey || env.stripePaymentLinkUrl),
    hasStripeWebhookSecret: Boolean(env.stripeWebhookSecret),
    listenerRunning
  };
}

// server/blaze/blazeApi.ts
var BlazeApiError = class extends Error {
  constructor(message, status, payload) {
    super(message);
    this.status = status;
    this.payload = payload;
  }
  status;
  payload;
};
var BlazeApiClient = class {
  apiBase = "https://api.blaze.stream/v1";
  authBase = "https://blaze.stream/bapi/oauth2";
  async generateAuthUrl(scopes = ["users.read", "offline.access", "channel.moderate"], redirectUri = env.blazeRedirectUri) {
    return this.authRequest("/generate-auth-url", {
      clientId: env.blazeClientId,
      clientSecret: env.blazeClientSecret,
      redirectUri,
      scopes
    });
  }
  async exchangeCode(code, codeVerifier, redirectUri = env.blazeRedirectUri) {
    const response = await this.authRequest("/token", {
      clientId: env.blazeClientId,
      clientSecret: env.blazeClientSecret,
      code,
      codeVerifier,
      redirectUri,
      grantType: "authorization_code"
    });
    return {
      type: "user",
      userId: response.userId,
      accessToken: response.accessToken,
      refreshToken: response.refreshToken,
      expiresAt: new Date(Date.now() + response.expiresIn * 1e3).toISOString(),
      scopes: response.scopes ?? []
    };
  }
  async refreshUserToken(refreshToken) {
    const response = await this.authRequest("/refresh", {
      clientId: env.blazeClientId,
      clientSecret: env.blazeClientSecret,
      refreshToken
    });
    return {
      type: "user",
      accessToken: response.accessToken,
      refreshToken: response.refreshToken,
      expiresAt: new Date(Date.now() + response.expiresIn * 1e3).toISOString(),
      scopes: response.scopes ?? []
    };
  }
  async getAppToken() {
    const response = await this.authRequest("/token", {
      clientId: env.blazeClientId,
      clientSecret: env.blazeClientSecret,
      grantType: "client_credentials"
    });
    return {
      type: "app",
      accessToken: response.accessToken,
      expiresAt: new Date(Date.now() + response.expiresIn * 1e3).toISOString(),
      scopes: []
    };
  }
  async getUserProfile(token) {
    return this.apiRequest("/users/profile", {
      token
    });
  }
  async listUserSubscriptions(token) {
    return this.apiRequest("/users/subscriptions", {
      token
    });
  }
  async listChannels(token, slug) {
    const url = new URL(`${this.apiBase}/channels`);
    url.searchParams.set("slug[]", slug);
    url.searchParams.set("type", "all");
    url.searchParams.set("limit", "1");
    const response = await fetch(url, {
      method: "GET",
      headers: {
        accept: "application/json",
        "client-id": env.blazeClientId,
        authorization: `Bearer ${token}`
      }
    });
    return parseBlazeResponse(response);
  }
  async listMessages(token, channelId, limit = 50) {
    return this.apiRequest("/chats/messages", {
      token,
      query: { channelId, limit }
    });
  }
  async sendChatMessage(token, body) {
    return this.apiRequest("/chats/messages", {
      method: "POST",
      token,
      body
    });
  }
  async deleteChatMessage(token, body) {
    return this.apiRequest("/chats/messages", {
      method: "DELETE",
      token,
      body
    });
  }
  async muteUser(token, body) {
    return this.apiRequest("/moderation/mute", {
      method: "POST",
      token,
      body
    });
  }
  async banUser(token, body) {
    return this.apiRequest("/moderation/ban", {
      method: "POST",
      token,
      body
    });
  }
  async subscribeEvent(token, body) {
    return this.apiRequest("/events/subscriptions", {
      method: "POST",
      token,
      body: {
        version: "1",
        ...body
      }
    });
  }
  async authRequest(path3, body) {
    if (!env.blazeClientId || !env.blazeClientSecret) {
      throw new BlazeApiError("Blaze Client ID and Client Secret are required.", 400, null);
    }
    const response = await fetch(`${this.authBase}${path3}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json"
      },
      body: JSON.stringify(body)
    });
    return parseBlazeResponse(response);
  }
  async apiRequest(path3, options = {}) {
    const url = new URL(`${this.apiBase}${path3}`);
    Object.entries(options.query ?? {}).forEach(([key, value]) => {
      if (value !== void 0) url.searchParams.set(key, String(value));
    });
    const response = await fetch(url, {
      method: options.method ?? "GET",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
        "client-id": env.blazeClientId,
        ...options.token ? { authorization: `Bearer ${options.token}` } : {}
      },
      body: options.body ? JSON.stringify(options.body) : void 0
    });
    return parseBlazeResponse(response);
  }
};
async function parseBlazeResponse(response) {
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;
  if (!response.ok) {
    throw new BlazeApiError(`Blaze API request failed with ${response.status}`, response.status, payload);
  }
  return payload;
}

// server/blaze/eventService.ts
import { io } from "socket.io-client";
var DEFAULT_EVENT_TYPES = [
  "channel.chat.message",
  "channel.follow",
  "channel.subscribe",
  "channel.subscription.gift",
  "channel.thanks",
  "channel.raid",
  "stream.online",
  "stream.offline"
];
var BlazeEventService = class {
  constructor(api2, onNotification) {
    this.api = api2;
    this.onNotification = onNotification;
  }
  api;
  onNotification;
  socket = null;
  running = false;
  isRunning() {
    return this.running;
  }
  stop() {
    this.socket?.disconnect();
    this.socket = null;
    this.running = false;
  }
  start(channelId, token) {
    if (this.running) return;
    if (!channelId) {
      throw new Error("Set a Blaze channel id before starting the listener.");
    }
    this.socket = io("https://blaze.stream", {
      path: "/ws",
      transports: ["websocket"]
    });
    this.socket.on("eventsub", async (message) => {
      const metadata = message.metadata ?? {};
      const payload = message.payload ?? {};
      if (metadata.messageType === "session_welcome") {
        const sessionId = String(payload.sessionId ?? "");
        await this.subscribeDefaults(token.accessToken, sessionId, channelId);
        this.running = true;
        return;
      }
      await this.onNotification({
        subscriptionType: String(metadata.subscriptionType ?? "unknown"),
        payload
      });
    });
    this.socket.on("disconnect", () => {
      this.running = false;
    });
  }
  async subscribeDefaults(accessToken, sessionId, channelId) {
    await Promise.all(
      DEFAULT_EVENT_TYPES.map(
        (type) => this.api.subscribeEvent(accessToken, {
          type,
          sessionId,
          condition: { channelId }
        }).catch(() => void 0)
      )
    );
  }
};
function eventPayloadToChatMessage(payload) {
  const sender = payload.sender;
  const message = payload.message;
  const messageId = payload.messageId;
  const channelId = payload.channelId;
  if (!sender || typeof message !== "string" || typeof messageId !== "string" || typeof channelId !== "string") {
    return null;
  }
  return {
    channelId,
    messageId,
    message,
    createdAt: typeof payload.createdAt === "string" ? payload.createdAt : (/* @__PURE__ */ new Date()).toISOString(),
    sender: {
      id: String(sender.id ?? sender.username ?? "unknown"),
      username: String(sender.username ?? sender.displayName ?? "viewer"),
      displayName: String(sender.displayName ?? sender.username ?? "Viewer"),
      avatarUrl: extractAvatarUrl(sender) || extractAvatarUrl(payload),
      roles: Array.isArray(sender.roles) ? sender.roles.map(String) : [],
      isBot: Boolean(sender.isBot),
      isSubscriber: Boolean(sender.isSubscriber),
      isFollower: Boolean(sender.isFollower),
      isOwner: Boolean(sender.isOwner)
    }
  };
}
function extractAvatarUrl(source) {
  const value = source.avatarUrl ?? source.avatarURL ?? source.avatar ?? source.profileImageUrl ?? source.profileImageURL ?? source.profilePictureUrl ?? source.profilePictureURL ?? source.imageUrl ?? source.picture;
  return typeof value === "string" && value.trim() ? value : void 0;
}

// server/bot/engine.ts
import { nanoid as nanoid3 } from "nanoid";

// server/ai/aiAssistant.ts
import OpenAI from "openai";
var openai = null;
function getClient() {
  if (!env.openAiApiKey) return null;
  openai ??= new OpenAI({ apiKey: env.openAiApiKey });
  return openai;
}
async function createAiReply(input) {
  const client = getClient();
  if (!client) {
    return fallbackReply(input.persona, input.message);
  }
  const response = await client.chat.completions.create({
    model: "gpt-4o-mini",
    temperature: 0.7,
    max_tokens: 110,
    messages: [
      {
        role: "system",
        content: "You are FRAGBOT, an energetic but respectful livestream chat assistant for BLAZE.STREAM. Keep replies short, fun, helpful, and safe. Do not insult viewers. Do not claim to moderate unless the local bot decision says so."
      },
      {
        role: "user",
        content: [
          `Persona: ${input.persona.name}, voice=${input.persona.voice}.`,
          `Context: ${input.context}`,
          `Viewer ${input.message.sender.displayName} said: ${input.message.message}`,
          "Reply in one sentence suitable for live chat."
        ].join("\n")
      }
    ]
  });
  return response.choices[0]?.message.content?.trim() || fallbackReply(input.persona, input.message);
}
function fallbackReply(persona, message) {
  const lower = message.message.toLowerCase();
  if (lower.includes("?")) {
    return `${message.sender.displayName}, good question. The streamer can pin the exact answer, but I am tracking it for the crew.`;
  }
  if (lower.includes("hype") || lower.includes("lets go") || lower.includes("let's go")) {
    return `${persona.catchphrases[0] ?? "Big energy."} ${message.sender.displayName} just lit up chat.`;
  }
  return `${message.sender.displayName}, I hear you. ${persona.catchphrases[1] ?? "Chat is cooking."}`;
}

// server/store/jsonStore.ts
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { nanoid as nanoid2 } from "nanoid";

// server/store/defaultState.ts
import { nanoid } from "nanoid";
var now = (/* @__PURE__ */ new Date()).toISOString();
function createDefaultState() {
  return {
    config: {
      channelId: "",
      botUserId: "",
      enabled: true,
      mode: "assist",
      plan: "free",
      safety: {
        badWords: ["scamword", "hateword"],
        blockedPhrases: ["free crypto giveaway", "click my shady link"],
        maxRepeatedMessages: 3,
        repeatedWindowSeconds: 25,
        maxCapsRatio: 0.75,
        linkPolicy: "followers",
        firstOffenseAction: "review",
        repeatOffenseAction: "mute"
      },
      aiPersona: {
        name: "FRAGBOT",
        voice: "energetic",
        catchphrases: ["Keep it blazing.", "Chat is cooking.", "Big energy."],
        autoReplyEnabled: true,
        autoReplyCooldownSeconds: 45,
        answerQuestions: true,
        hypeMoments: true
      }
    },
    billing: {
      status: "free",
      fragbotSubscriberMonths: 0,
      cptfiveSubscriberMonths: 0,
      trialRedeemed: false
    },
    streamer: {
      loggedIn: false,
      email: "",
      userId: "",
      username: "",
      userSlug: "",
      displayName: "",
      avatarUrl: "",
      channelSlug: "",
      channelId: "",
      botAdded: false,
      blazeConnected: false
    },
    commands: [
      {
        id: nanoid(),
        command: "!socials",
        response: "Follow the creator everywhere: Blaze, X, YouTube, and Discord links are in the profile.",
        enabled: true,
        proOnly: false,
        cooldownSeconds: 15,
        uses: 0
      },
      {
        id: nanoid(),
        command: "!schedule",
        response: "Streams run Tuesday, Thursday, and Saturday. Drop a follow so you never miss one.",
        enabled: true,
        proOnly: false,
        cooldownSeconds: 20,
        uses: 0
      }
    ],
    timers: [
      {
        id: nanoid(),
        title: "Follow reminder",
        message: "Enjoying the stream? Follow the channel and join the next one live.",
        intervalMinutes: 12,
        enabled: true,
        proOnly: false
      },
      {
        id: nanoid(),
        title: "Community reminder",
        message: "Keep chat sharp, funny, and respectful. FRAGBOT is watching the vibes.",
        intervalMinutes: 20,
        enabled: true,
        proOnly: true
      }
    ],
    games: [
      {
        id: nanoid(),
        command: "!roll",
        name: "Lucky Roll",
        enabled: true,
        proOnly: false,
        rewardXp: 15,
        cooldownSeconds: 20,
        description: "Roll 1-100 for a quick XP burst."
      },
      {
        id: nanoid(),
        command: "!heist",
        name: "Blaze Heist",
        enabled: true,
        proOnly: true,
        rewardXp: 45,
        cooldownSeconds: 60,
        description: "A group mini-game with risk, reward, and leaderboard movement."
      }
    ],
    rewards: [
      {
        id: nanoid(),
        label: "Hype blast",
        command: "!hype",
        enabled: true,
        proOnly: false,
        cost: 50,
        effect: "ai_hype"
      },
      {
        id: nanoid(),
        label: "Overlay sparkle",
        command: "!spark",
        enabled: true,
        proOnly: true,
        cost: 120,
        effect: "overlay"
      }
    ],
    giveaways: [],
    loyalty: [
      {
        id: "viewer-1",
        username: "nova",
        displayName: "Nova",
        xp: 1450,
        watchMinutes: 440,
        rank: "Inferno",
        lastSeenAt: now
      },
      {
        id: "viewer-2",
        username: "pixelrush",
        displayName: "PixelRush",
        xp: 980,
        watchMinutes: 320,
        rank: "Flamekeeper",
        lastSeenAt: now
      },
      {
        id: "viewer-3",
        username: "luckybyte",
        displayName: "LuckyByte",
        xp: 520,
        watchMinutes: 160,
        rank: "Spark",
        lastSeenAt: now
      }
    ],
    reviewQueue: [],
    events: [
      {
        id: nanoid(),
        type: "system",
        title: "FRAGBOT booted",
        detail: "Local bot engine is ready. Connect a Blaze channel to listen live.",
        createdAt: now
      }
    ],
    authSessions: [],
    tokens: {},
    analytics: {
      messagesScanned: 0,
      actionsTaken: 0,
      commandsRun: 0,
      xpAwarded: 0
    }
  };
}

// server/store/jsonStore.ts
var dataDir = path.resolve(process.cwd(), "data");
var statePath = path.join(dataDir, "fragbot-state.json");
var legacyStatePath = path.join(dataDir, "blazebot-state.json");
var cache = null;
async function persist(state) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(statePath, `${JSON.stringify(state, null, 2)}
`, "utf8");
}
async function readState() {
  if (cache) return cache;
  try {
    const raw = await readFile(statePath, "utf8").catch(() => readFile(legacyStatePath, "utf8"));
    cache = JSON.parse(raw);
    normalizeState(cache);
  } catch {
    cache = createDefaultState();
    normalizeState(cache);
    await persist(cache);
  }
  return cache;
}
function normalizeState(state) {
  if (!state.billing) {
    state.billing = {
      status: "free",
      fragbotSubscriberMonths: 0,
      cptfiveSubscriberMonths: 0,
      trialRedeemed: false
    };
  }
  if (!state.streamer) {
    state.streamer = {
      loggedIn: false,
      email: "",
      userId: "",
      username: "",
      userSlug: "",
      displayName: "",
      avatarUrl: "",
      channelSlug: "",
      channelId: "",
      botAdded: false,
      blazeConnected: false
    };
  }
  state.billing.status = state.billing.status ?? "free";
  state.billing.fragbotSubscriberMonths = state.billing.fragbotSubscriberMonths ?? 0;
  state.billing.cptfiveSubscriberMonths = state.billing.cptfiveSubscriberMonths ?? 0;
  state.billing.trialRedeemed = state.billing.trialRedeemed ?? false;
  state.streamer.loggedIn = state.streamer.loggedIn ?? false;
  state.streamer.email = state.streamer.email ?? "";
  state.streamer.userId = state.streamer.userId ?? "";
  state.streamer.username = state.streamer.username ?? "";
  state.streamer.userSlug = state.streamer.userSlug ?? state.streamer.username ?? "";
  state.streamer.displayName = state.streamer.displayName ?? "";
  state.streamer.avatarUrl = state.streamer.avatarUrl ?? "";
  state.streamer.channelSlug = state.streamer.channelSlug ?? "";
  state.streamer.channelId = state.streamer.channelId ?? "";
  state.streamer.botAdded = state.streamer.botAdded ?? false;
  state.streamer.blazeConnected = state.streamer.blazeConnected ?? false;
  if (!state.streamer.blazeConnected || !state.streamer.userId) {
    state.streamer.loggedIn = false;
    state.streamer.botAdded = false;
  }
  state.giveaways = (state.giveaways ?? []).map(normalizeGiveawayRecord);
  state.loyalty = (state.loyalty ?? []).map(normalizeLoyaltyViewer);
  state.reviewQueue = (state.reviewQueue ?? []).map(normalizeReviewItem);
  state.commands = state.commands.filter((command) => command.command.toLowerCase() !== "!clip");
  state.events = state.events.filter((event) => event.type !== "clip" && !event.title.toLowerCase().includes("clip"));
  delete state.clips;
  const legacyName = "BlazeBot";
  if (state.config.aiPersona.name === legacyName) {
    state.config.aiPersona.name = "FRAGBOT";
  }
  for (const timer of state.timers) {
    timer.message = timer.message.replaceAll(legacyName, "FRAGBOT");
  }
  for (const event of state.events) {
    event.title = event.title.replaceAll(legacyName, "FRAGBOT");
    event.detail = event.detail.replaceAll(legacyName, "FRAGBOT");
  }
}
function normalizeGiveawayRecord(record) {
  const legacy = record;
  const subscriberMultiplier = clampInt(Number(legacy.subscriberMultiplier ?? 2), 1, 10);
  const entries = Array.isArray(legacy.entries) ? legacy.entries.map((entry) => normalizeGiveawayEntry(entry, subscriberMultiplier)) : [];
  const winner = legacy.winner ? normalizeGiveawayEntry(legacy.winner, subscriberMultiplier) : void 0;
  const status = legacy.status === "open" || legacy.status === "draft" ? legacy.status : "closed";
  return {
    id: legacy.id || nanoid2(),
    channelId: legacy.channelId || "unassigned-channel",
    channelSlug: legacy.channelSlug || "unassigned",
    title: legacy.title || "Chat Giveaway",
    prize: typeof legacy.prize === "string" && legacy.prize.trim() ? legacy.prize : legacy.prizeAmount ? `${legacy.prizeAmount} $BLAZE streamer-sponsored prize` : "Stream prize",
    entryPhrase: typeof legacy.entryPhrase === "string" && legacy.entryPhrase.trim() ? legacy.entryPhrase : legacy.command || "!enter",
    subscriberMultiplier,
    source: "manual",
    status,
    entries,
    winner,
    createdAt: legacy.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
    openedAt: legacy.openedAt,
    closedAt: legacy.closedAt
  };
}
function normalizeGiveawayEntry(entry, subscriberMultiplier) {
  const isSubscriber = Boolean(entry.isSubscriber);
  return {
    userId: entry.userId || nanoid2(),
    username: entry.username || "viewer",
    displayName: entry.displayName || entry.username || "Viewer",
    avatarUrl: entry.avatarUrl || "",
    isSubscriber,
    weight: clampInt(Number(entry.weight ?? (isSubscriber ? subscriberMultiplier : 1)), 1, 10),
    createdAt: entry.createdAt || (/* @__PURE__ */ new Date()).toISOString()
  };
}
function normalizeLoyaltyViewer(viewer) {
  return {
    ...viewer,
    avatarUrl: viewer.avatarUrl ?? ""
  };
}
function normalizeReviewItem(item) {
  return {
    ...item,
    message: {
      ...item.message,
      sender: {
        ...item.message.sender,
        avatarUrl: item.message.sender.avatarUrl ?? ""
      }
    }
  };
}
function clampInt(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.trunc(value)));
}
async function writeState(mutator) {
  const state = await readState();
  await mutator(state);
  await persist(state);
  return state;
}
async function addEvent(event) {
  return writeState((state) => {
    state.events.unshift(event);
    state.events = state.events.slice(0, 80);
  });
}
async function addReviewItem(item) {
  return writeState((state) => {
    state.reviewQueue.unshift(item);
    state.reviewQueue = state.reviewQueue.slice(0, 60);
  });
}
async function storeToken(token) {
  return writeState((state) => {
    state.tokens[token.type] = token;
  });
}

// server/utils/rank.ts
function rankForXp(xp) {
  if (xp >= 2500) return "Blaze Legend";
  if (xp >= 1200) return "Inferno";
  if (xp >= 700) return "Flamekeeper";
  if (xp >= 300) return "Torchbearer";
  return "Spark";
}
function capsRatio(value) {
  const letters = value.replace(/[^a-z]/gi, "");
  if (!letters.length) return 0;
  const caps = letters.replace(/[^A-Z]/g, "");
  return caps.length / letters.length;
}
function includesLink(value) {
  return /\b(?:https?:\/\/|www\.|[\w-]+\.(?:com|net|gg|io|tv|stream)\b)/i.test(value);
}

// server/bot/engine.ts
var userMessageHistory = /* @__PURE__ */ new Map();
var commandCooldowns = /* @__PURE__ */ new Map();
var aiCooldowns = /* @__PURE__ */ new Map();
async function handleChatMessage(message) {
  const state = await readState();
  const decision = await decideChatActions(state, message);
  await writeState((draft) => {
    draft.analytics.messagesScanned += 1;
    draft.analytics.actionsTaken += decision.actions.length;
    draft.analytics.xpAwarded += decision.xpAwarded;
    if (decision.actions.includes("reply") || decision.actions.includes("reward")) {
      draft.analytics.commandsRun += 1;
    }
    awardViewerXp(draft, message, decision.xpAwarded);
  });
  const events = decision.actions.map((action) => actionToEvent(action, decision, message));
  for (const event of events) {
    await addEvent(event);
  }
  if (decision.actions.includes("review")) {
    await addReviewItem(createReviewItem(message, decision));
  }
  return decision;
}
async function decideChatActions(state, message) {
  if (message.sender.isBot || !state.config.enabled) {
    return {
      actions: [],
      reason: "Ignored bot or disabled configuration.",
      severity: "low",
      xpAwarded: 0
    };
  }
  const moderation = evaluateSafety(state, message);
  if (moderation) return moderation;
  const command = findCommand(state.commands, message);
  if (command) {
    return runCommand(state, command, message);
  }
  const game = findGame(state.games, message);
  if (game) {
    return runGame(state, game, message);
  }
  const reward = findReward(state.rewards, message);
  if (reward) {
    return runReward(state, reward, message);
  }
  const shouldAskAi = state.config.aiPersona.autoReplyEnabled && (state.config.aiPersona.answerQuestions ? message.message.includes("?") : false);
  if (shouldAskAi && isCooldownReady(`ai:${message.sender.id}`, state.config.aiPersona.autoReplyCooldownSeconds, aiCooldowns)) {
    const reply = await createAiReply({
      persona: state.config.aiPersona,
      message,
      context: `Bot mode is ${state.config.mode}; plan is ${state.config.plan}.`
    });
    return {
      actions: state.config.mode === "observe" ? ["review"] : ["reply"],
      reply,
      reason: "AI answered a viewer question.",
      severity: "low",
      xpAwarded: 4
    };
  }
  return {
    actions: ["reward"],
    reason: "Healthy chat activity awarded loyalty XP.",
    severity: "low",
    xpAwarded: 2
  };
}
function evaluateSafety(state, message) {
  const body = message.message.trim();
  const lower = body.toLowerCase();
  const rule = state.config.safety;
  const history = recordAndReadHistory(message.sender.id, body, rule.repeatedWindowSeconds);
  const blockedTerm = [...rule.badWords, ...rule.blockedPhrases].find((term) => lower.includes(term.toLowerCase()));
  const repeatedCount = history.filter((item) => item.body.toLowerCase() === lower).length;
  const linkBlocked = includesLink(body) && (rule.linkPolicy === "block" || rule.linkPolicy === "followers" && !message.sender.isFollower || rule.linkPolicy === "subs" && !message.sender.isSubscriber);
  const capsBlocked = body.length > 18 && capsRatio(body) >= rule.maxCapsRatio;
  if (!blockedTerm && repeatedCount < rule.maxRepeatedMessages && !linkBlocked && !capsBlocked) {
    return null;
  }
  const severe = Boolean(blockedTerm || repeatedCount >= rule.maxRepeatedMessages + 1);
  const action = severe ? rule.repeatOffenseAction : rule.firstOffenseAction;
  const actions = state.config.mode === "observe" ? ["review"] : [action, "review"];
  return {
    actions,
    reason: [
      blockedTerm ? `Blocked phrase: ${blockedTerm}` : "",
      repeatedCount >= rule.maxRepeatedMessages ? "Repeated message spam" : "",
      linkBlocked ? "Link policy violation" : "",
      capsBlocked ? "Excessive caps" : ""
    ].filter(Boolean).join("; "),
    severity: severe ? "high" : "medium",
    xpAwarded: 0
  };
}
function findCommand(commands, message) {
  const firstWord = message.message.trim().split(/\s+/)[0]?.toLowerCase();
  return commands.find((command) => command.enabled && command.command.toLowerCase() === firstWord);
}
function findGame(games, message) {
  const firstWord = message.message.trim().split(/\s+/)[0]?.toLowerCase();
  return games.find((game) => game.enabled && game.command.toLowerCase() === firstWord);
}
function findReward(rewards, message) {
  const firstWord = message.message.trim().split(/\s+/)[0]?.toLowerCase();
  return rewards.find((reward) => reward.enabled && reward.command.toLowerCase() === firstWord);
}
function runCommand(state, command, message) {
  if (command.proOnly && state.config.plan !== "pro") {
    return {
      actions: ["review"],
      reason: `${command.command} is a Pro command. Upgrade gate was triggered.`,
      severity: "low",
      xpAwarded: 0
    };
  }
  if (!isCooldownReady(`cmd:${command.id}:${message.sender.id}`, command.cooldownSeconds, commandCooldowns)) {
    return {
      actions: [],
      reason: `${command.command} is cooling down.`,
      severity: "low",
      xpAwarded: 0
    };
  }
  command.uses += 1;
  return {
    actions: ["reply", "reward"],
    reply: command.response,
    reason: `Ran custom command ${command.command}.`,
    severity: "low",
    xpAwarded: 6
  };
}
function runGame(state, game, message) {
  if (game.proOnly && state.config.plan !== "pro") {
    return {
      actions: ["reply"],
      reply: `${message.sender.displayName}, ${game.name} is a Pro game. Try !roll for free XP.`,
      reason: "Game blocked by plan gate.",
      severity: "low",
      xpAwarded: 0
    };
  }
  if (!isCooldownReady(`game:${game.id}:${message.sender.id}`, game.cooldownSeconds, commandCooldowns)) {
    return {
      actions: [],
      reason: `${game.name} is cooling down.`,
      severity: "low",
      xpAwarded: 0
    };
  }
  const roll = Math.ceil(Math.random() * 100);
  const bonus = roll >= 90 ? game.rewardXp * 2 : game.rewardXp;
  return {
    actions: ["reply", "reward"],
    reply: `${message.sender.displayName} rolled ${roll}. ${roll >= 90 ? "Jackpot energy." : "XP added."} +${bonus} XP`,
    reason: `Played ${game.name}.`,
    severity: "low",
    xpAwarded: bonus
  };
}
function runReward(state, reward, message) {
  if (reward.proOnly && state.config.plan !== "pro") {
    return {
      actions: ["reply"],
      reply: `${message.sender.displayName}, ${reward.label} is a Pro reward. The streamer can unlock it from FRAGBOT Pro.`,
      reason: "Reward blocked by plan gate.",
      severity: "low",
      xpAwarded: 0
    };
  }
  return {
    actions: ["reply", "reward"],
    reply: `${reward.label} triggered by ${message.sender.displayName}. FRAGBOT is firing the ${reward.effect.replace("_", " ")} effect.`,
    reason: `Triggered reward ${reward.label}.`,
    severity: "low",
    xpAwarded: 10
  };
}
function awardViewerXp(state, message, xp) {
  if (xp <= 0) return;
  const viewer = state.loyalty.find((item) => item.id === message.sender.id || item.username.toLowerCase() === message.sender.username.toLowerCase()) ?? {
    id: message.sender.id,
    username: message.sender.username,
    displayName: message.sender.displayName,
    avatarUrl: message.sender.avatarUrl,
    xp: 0,
    watchMinutes: 0,
    rank: "Spark",
    lastSeenAt: message.createdAt
  };
  viewer.displayName = message.sender.displayName;
  viewer.avatarUrl = message.sender.avatarUrl ?? viewer.avatarUrl;
  viewer.xp += xp;
  viewer.watchMinutes += 1;
  viewer.rank = rankForXp(viewer.xp);
  viewer.lastSeenAt = message.createdAt;
  const index = state.loyalty.findIndex((item) => item.id === viewer.id || item.username.toLowerCase() === viewer.username.toLowerCase());
  if (index >= 0) state.loyalty[index] = viewer;
  else state.loyalty.push(viewer);
  state.loyalty.sort((a, b) => b.xp - a.xp);
}
function recordAndReadHistory(userId, body, windowSeconds) {
  const now2 = Date.now();
  const history = userMessageHistory.get(userId) ?? [];
  const filtered = history.filter((entry) => now2 - entry.at <= windowSeconds * 1e3);
  filtered.push({ body, at: now2 });
  userMessageHistory.set(userId, filtered);
  return filtered;
}
function isCooldownReady(key, seconds, cache2) {
  const now2 = Date.now();
  const until = cache2.get(key) ?? 0;
  if (until > now2) return false;
  cache2.set(key, now2 + seconds * 1e3);
  return true;
}
function createReviewItem(message, decision) {
  return {
    id: nanoid3(),
    status: "open",
    severity: decision.severity,
    reason: decision.reason,
    message,
    suggestedActions: decision.actions,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function actionToEvent(action, decision, message) {
  const titles = {
    reply: "Bot reply queued",
    delete: "Message delete recommended",
    mute: "Viewer timeout recommended",
    ban: "Ban recommended",
    reward: "XP awarded",
    review: "Review item opened",
    announce: "Timer announcement sent"
  };
  return {
    id: nanoid3(),
    type: action,
    title: titles[action] ?? "Bot action",
    detail: decision.reply ?? `${message.sender.displayName}: ${decision.reason}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}

// server/bot/timerService.ts
import { nanoid as nanoid4 } from "nanoid";
var TimerService = class {
  constructor(api2) {
    this.api = api2;
  }
  api;
  interval = null;
  start() {
    if (this.interval) return;
    this.interval = setInterval(() => {
      void this.tick();
    }, 3e4);
  }
  stop() {
    if (!this.interval) return;
    clearInterval(this.interval);
    this.interval = null;
  }
  async tick() {
    const state = await readState();
    const due = findDueTimer(state);
    if (!due) return;
    const token = state.tokens.user ?? state.tokens.app;
    if (state.config.channelId && token) {
      await this.api.sendChatMessage(token.accessToken, {
        channelId: state.config.channelId,
        message: due.message,
        ...token.type === "app" && state.config.botUserId ? { senderId: state.config.botUserId } : {}
      }).catch(() => void 0);
    }
    await writeState((draft) => {
      const timer = draft.timers.find((item) => item.id === due.id);
      if (timer) timer.lastSentAt = (/* @__PURE__ */ new Date()).toISOString();
    });
    await addEvent({
      id: nanoid4(),
      type: "announce",
      title: `Timer sent: ${due.title}`,
      detail: due.message,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
};
function findDueTimer(state) {
  const now2 = Date.now();
  return state.timers.find((timer) => {
    if (!timer.enabled) return false;
    if (timer.proOnly && state.config.plan !== "pro") return false;
    if (!timer.lastSentAt) return true;
    return now2 - new Date(timer.lastSentAt).getTime() >= timer.intervalMinutes * 6e4;
  });
}

// server/index.ts
var app = express();
var api = new BlazeApiClient();
var stripe = env.stripeSecretKey ? new Stripe(env.stripeSecretKey, { apiVersion: "2026-06-24.dahlia" }) : null;
var timerService = new TimerService(api);
var eventService = new BlazeEventService(api, async ({ subscriptionType, payload }) => {
  if (subscriptionType === "channel.chat.message") {
    const chat = eventPayloadToChatMessage(payload);
    if (chat) {
      await recordGiveawayEntries(chat);
      const decision = await handleChatMessage(chat);
      await executeBlazeActions(chat, decision);
    }
    return;
  }
  await addEvent({
    id: nanoid5(),
    type: "system",
    title: subscriptionType,
    detail: summarizePayload(payload),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
});
timerService.start();
app.use(cors({ origin: env.clientUrl, credentials: true }));
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (request, response) => {
  if (!stripe || !env.stripeWebhookSecret) {
    response.status(501).json({ error: "Stripe webhook is not configured." });
    return;
  }
  const signature = request.header("stripe-signature");
  if (!signature) {
    response.status(400).json({ error: "Missing Stripe signature." });
    return;
  }
  try {
    const event = stripe.webhooks.constructEvent(request.body, signature, env.stripeWebhookSecret);
    await handleStripeEvent(event);
    response.json({ received: true });
  } catch (error) {
    response.status(400).json({ error: error instanceof Error ? error.message : "Invalid Stripe webhook." });
  }
});
app.use(express.json({ limit: "1mb" }));
app.get("/api/health", async (_request, response) => {
  response.json({
    ok: true,
    name: "FRAGBOT",
    connection: safeConnectionStatus(eventService.isRunning())
  });
});
app.get("/api/dashboard", async (_request, response) => {
  const state = await readState();
  response.json(buildDashboardSnapshot(state));
});
app.patch("/api/config", async (request, response) => {
  const schema = z.object({
    channelId: z.string().optional(),
    botUserId: z.string().optional(),
    enabled: z.boolean().optional(),
    mode: z.enum(["observe", "assist", "autopilot"]).optional(),
    safety: z.record(z.unknown()).optional(),
    aiPersona: z.record(z.unknown()).optional()
  });
  const patch = schema.parse(request.body);
  const current = await readState();
  if (patch.mode === "autopilot" && !hasProAccess(current.billing)) {
    response.status(402).json({ error: "Autopilot is a Pro feature. Upgrade or redeem an eligible FRAGBOT subscriber trial." });
    return;
  }
  const state = await writeState((draft) => {
    draft.config = {
      ...draft.config,
      ...patch,
      safety: { ...draft.config.safety, ...patch.safety ?? {} },
      aiPersona: { ...draft.config.aiPersona, ...patch.aiPersona ?? {} }
    };
    draft.config.plan = derivePlan(draft.billing);
    if (draft.config.plan === "free" && draft.config.mode === "autopilot") {
      draft.config.mode = "assist";
    }
  });
  response.json(state.config);
});
app.post("/api/streamer/login", async (request, response) => {
  const body = z.object({
    email: z.string().min(1).max(120),
    username: z.string().min(1).max(80).optional(),
    displayName: z.string().min(1).max(80)
  }).parse(request.body);
  const userSlug = normalizeSlug(body.username ?? body.email);
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  const state = await writeState((draft) => {
    draft.streamer = {
      ...draft.streamer,
      loggedIn: true,
      email: body.email,
      username: draft.streamer.username || userSlug,
      userSlug: draft.streamer.userSlug || userSlug,
      displayName: body.displayName,
      createdAt: draft.streamer.createdAt ?? now2,
      updatedAt: now2
    };
  });
  response.json(state.streamer);
});
app.post("/api/streamer/add-bot", async (request, response) => {
  const body = z.object({
    channelSlug: z.string().min(1).max(80),
    channelId: z.string().min(1).max(120)
  }).parse(request.body);
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  const state = await writeState((draft) => {
    draft.streamer = {
      ...draft.streamer,
      channelSlug: body.channelSlug,
      channelId: body.channelId,
      botAdded: true,
      updatedAt: now2
    };
    draft.config.channelId = body.channelId;
  });
  response.json(state.streamer);
});
app.post("/api/streamer/logout", async (_request, response) => {
  const state = await writeState((draft) => {
    draft.streamer.loggedIn = false;
    draft.streamer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  });
  response.json(state.streamer);
});
app.post("/api/billing/checkout", async (_request, response, next) => {
  try {
    const state = await readState();
    if (!stripe) {
      if (env.stripePaymentLinkUrl) {
        await recordBillingEvent("Stripe Payment Link opened", "Hosted Stripe Payment Link was used for FRAGBOT Pro checkout.");
        response.json({
          checkoutConfigured: true,
          checkoutUrl: buildStripePaymentLinkUrl(env.stripePaymentLinkUrl, state),
          message: "Opening Stripe checkout for FRAGBOT Pro.",
          paymentLinkMode: true
        });
        return;
      }
      await recordBillingEvent("Pro checkout unavailable", "Stripe checkout is not configured. Add STRIPE_SECRET_KEY or STRIPE_PAYMENT_LINK_URL.");
      response.status(501).json({
        checkoutConfigured: false,
        message: "Stripe checkout is not configured yet. Add STRIPE_SECRET_KEY for Checkout Sessions, or STRIPE_PAYMENT_LINK_URL for a hosted Stripe checkout link."
      });
      return;
    }
    const lineItem = env.stripeProPriceId ? { price: env.stripeProPriceId, quantity: 1 } : {
      price_data: {
        currency: "usd",
        unit_amount: 999,
        recurring: { interval: "month" },
        product_data: {
          name: "FRAGBOT Pro",
          description: "Advanced AI moderation, commands, games, rewards, and loyalty tools for Blaze streamers."
        }
      },
      quantity: 1
    };
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [lineItem],
      customer: state.billing.stripeCustomerId || void 0,
      customer_email: !state.billing.stripeCustomerId && state.streamer.email.includes("@") ? state.streamer.email : void 0,
      client_reference_id: getStripeClientReference(state),
      success_url: `${env.clientUrl}/billing?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${env.clientUrl}/billing?checkout=cancelled`,
      metadata: {
        channelId: state.streamer.channelId || state.config.channelId || "",
        channelSlug: state.streamer.channelSlug || "",
        streamerUserId: state.streamer.userId || ""
      },
      subscription_data: {
        metadata: {
          channelId: state.streamer.channelId || state.config.channelId || "",
          channelSlug: state.streamer.channelSlug || "",
          streamerUserId: state.streamer.userId || ""
        }
      },
      allow_promotion_codes: true
    });
    await writeState((draft) => {
      draft.billing.lastCheckoutAttemptAt = (/* @__PURE__ */ new Date()).toISOString();
      draft.billing.stripeCheckoutSessionId = session.id;
      draft.events.unshift({
        id: nanoid5(),
        type: "system",
        title: "Stripe Pro checkout started",
        detail: "$9.99/mo hosted Checkout session was created. Pro unlock waits for Stripe confirmation.",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      draft.events = draft.events.slice(0, 80);
    });
    response.json({ checkoutConfigured: true, checkoutUrl: session.url, message: "Opening Stripe Checkout for FRAGBOT Pro." });
  } catch (error) {
    next(error);
  }
});
app.post("/api/billing/checkout/confirm", async (request, response, next) => {
  try {
    if (!stripe) {
      response.status(501).json({ error: "Stripe is not configured." });
      return;
    }
    const body = z.object({ sessionId: z.string().min(1) }).parse(request.body);
    const session = await stripe.checkout.sessions.retrieve(body.sessionId, { expand: ["subscription"] });
    if (session.mode !== "subscription" || session.payment_status !== "paid") {
      response.status(402).json({ error: "Stripe checkout has not completed payment yet." });
      return;
    }
    await applyCheckoutSession(session);
    const state = await readState();
    response.json({ billing: state.billing, entitlements: createEntitlements(state.billing) });
  } catch (error) {
    next(error);
  }
});
app.post("/api/billing/portal", async (_request, response, next) => {
  try {
    const state = await readState();
    if (!stripe || !state.billing.stripeCustomerId) {
      response.status(501).json({ error: "Billing portal is available after a Stripe customer is created." });
      return;
    }
    const session = await stripe.billingPortal.sessions.create({
      customer: state.billing.stripeCustomerId,
      return_url: `${env.clientUrl}/billing`
    });
    response.json({ portalUrl: session.url });
  } catch (error) {
    next(error);
  }
});
app.post("/api/billing/redeem-fragbot-trial", async (_request, response) => {
  const current = await readState();
  if (current.billing.trialRedeemed) {
    response.status(409).json({ error: "The free FRAGBOT subscriber trial has already been redeemed." });
    return;
  }
  if (current.billing.cptfiveSubscriberMonths < 3) {
    response.status(403).json({ error: "This account needs 3 verified months subscribed to cptfive before the trial unlocks." });
    return;
  }
  const trialEndsAt = addDays(/* @__PURE__ */ new Date(), 30).toISOString();
  const state = await writeState((draft) => {
    draft.billing.status = "trial";
    draft.billing.trialEndsAt = trialEndsAt;
    draft.billing.trialRedeemed = true;
    draft.config.plan = "pro";
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title: "FRAGBOT trial redeemed",
      detail: "A 30 day Pro trial was unlocked from verified cptfive subscriber history.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
  response.json({ billing: state.billing, entitlements: createEntitlements(state.billing) });
});
app.post("/api/billing/cptfive-subscription/sync", async (_request, response, next) => {
  try {
    const state = await readState();
    if (!state.tokens.user) {
      response.status(400).json({ error: "Connect the streamer's Blaze account before checking cptfive subscriber eligibility." });
      return;
    }
    const months = await getCptfiveSubscriberMonths(state.tokens.user);
    const updated = await writeState((draft) => {
      draft.billing.cptfiveSubscriberMonths = months;
      draft.events.unshift({
        id: nanoid5(),
        type: "system",
        title: "cptfive subscription checked",
        detail: `${months} verified month${months === 1 ? "" : "s"} found in the signed-in user's Blaze subscriptions for cptfive.`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      draft.events = draft.events.slice(0, 80);
    });
    response.json({ billing: updated.billing, entitlements: createEntitlements(updated.billing) });
  } catch (error) {
    next(error);
  }
});
app.post("/api/billing/fragbot-subscription/verify", async (request, response) => {
  const token = String(request.header("x-fragbot-admin-token") ?? "");
  if (!env.fragbotAdminToken || token !== env.fragbotAdminToken) {
    response.status(403).json({ error: "Subscriber verification requires a server-side FRAGBOT admin token." });
    return;
  }
  const body = z.object({
    streamerEmail: z.string().min(1).max(120).optional(),
    months: z.number().int().min(0).max(120)
  }).parse(request.body);
  const state = await writeState((draft) => {
    draft.billing.fragbotSubscriberMonths = body.months;
    if (body.streamerEmail) draft.streamer.email = body.streamerEmail;
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title: "FRAGBOT subscriber history verified",
      detail: `${body.months} verified month${body.months === 1 ? "" : "s"} subscribed to @${env.blazeBotAccount}.`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
  response.json({ billing: state.billing, entitlements: createEntitlements(state.billing) });
});
app.post("/api/billing/cptfive-subscription/verify", async (request, response) => {
  const token = String(request.header("x-fragbot-admin-token") ?? "");
  if (!env.fragbotAdminToken || token !== env.fragbotAdminToken) {
    response.status(403).json({ error: "Subscriber verification requires a server-side FRAGBOT admin token." });
    return;
  }
  const body = z.object({
    streamerEmail: z.string().min(1).max(120).optional(),
    months: z.number().int().min(0).max(120)
  }).parse(request.body);
  const state = await writeState((draft) => {
    draft.billing.cptfiveSubscriberMonths = body.months;
    if (body.streamerEmail) draft.streamer.email = body.streamerEmail;
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title: "cptfive subscriber history verified",
      detail: `${body.months} verified month${body.months === 1 ? "" : "s"} subscribed to cptfive.`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
  response.json({ billing: state.billing, entitlements: createEntitlements(state.billing) });
});
app.post("/api/blaze/auth-url", async (_request, response, next) => {
  try {
    const result = await generateBlazeAuthUrl("streamer");
    await writeState((draft) => {
      draft.authSessions.unshift({
        state: result.state,
        codeVerifier: result.codeVerifier,
        redirectUri: result.redirectUri,
        purpose: "streamer",
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      draft.authSessions = draft.authSessions.slice(0, 5);
    });
    response.json({ url: result.url, redirectUri: result.redirectUri });
  } catch (error) {
    next(error);
  }
});
app.get("/api/blaze/callback", async (request, response, next) => {
  try {
    const code = String(request.query.code ?? "");
    const returnedState = String(request.query.state ?? "");
    const state = await readState();
    const session = state.authSessions.find((item) => item.state === returnedState);
    if (!code || !session) {
      response.status(400).send("Invalid Blaze OAuth callback.");
      return;
    }
    const token = await api.exchangeCode(code, session.codeVerifier, session.redirectUri);
    await storeToken({ ...token, type: "user" });
    await syncStreamerIdentity({ ...token, type: "user" });
    await addEvent({
      id: nanoid5(),
      type: "system",
      title: "Streamer Blaze account connected",
      detail: `Granted scopes: ${token.scopes.join(", ") || "none reported"}`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    response.redirect(`${env.clientUrl}/add-bot?connected=blaze`);
  } catch (error) {
    next(error);
  }
});
app.post("/api/blaze/sync-streamer", async (_request, response, next) => {
  try {
    const state = await readState();
    if (!state.tokens.user) {
      response.status(400).json({ error: "Connect with Blaze before syncing the streamer profile." });
      return;
    }
    const streamer = await syncStreamerIdentity(state.tokens.user);
    response.json(streamer);
  } catch (error) {
    next(error);
  }
});
app.post("/api/blaze/app-token", async (_request, response, next) => {
  try {
    const token = await api.getAppToken();
    await storeToken(token);
    await addEvent({
      id: nanoid5(),
      type: "system",
      title: "Blaze app token ready",
      detail: "Server-to-server app access token was generated.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});
app.post("/api/blaze/listener/start", async (_request, response, next) => {
  try {
    const state = await readState();
    const token = state.tokens.user ?? state.tokens.app;
    if (!token) {
      response.status(400).json({ error: "Connect Blaze or generate an app token before starting the listener." });
      return;
    }
    eventService.start(state.config.channelId, token);
    await addEvent({
      id: nanoid5(),
      type: "system",
      title: "Blaze listener starting",
      detail: "Socket.IO EventSub listener is connecting to Blaze.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});
app.post("/api/blaze/listener/stop", async (_request, response) => {
  eventService.stop();
  await addEvent({
    id: nanoid5(),
    type: "system",
    title: "Blaze listener stopped",
    detail: "Live event subscription was disconnected.",
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  response.json({ ok: true });
});
app.post("/api/simulate/chat", async (request, response, next) => {
  try {
    const body = z.object({
      message: z.string().min(1).max(500),
      username: z.string().default("testviewer"),
      displayName: z.string().default("Test Viewer"),
      avatarUrl: z.string().url().optional(),
      isSubscriber: z.boolean().default(false)
    }).parse(request.body);
    const state = await readState();
    const chat = {
      channelId: state.config.channelId || "local-dev-channel",
      messageId: nanoid5(),
      message: body.message,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      sender: {
        id: `local-${body.username.toLowerCase()}`,
        username: body.username,
        displayName: body.displayName,
        avatarUrl: body.avatarUrl,
        isFollower: true,
        isSubscriber: body.isSubscriber,
        roles: []
      }
    };
    await recordGiveawayEntries(chat);
    const decision = await handleChatMessage(chat);
    await executeBlazeActions(chat, decision);
    response.json({ chat, decision });
  } catch (error) {
    next(error);
  }
});
app.post("/api/chat/send", async (request, response, next) => {
  try {
    const body = z.object({ message: z.string().min(1).max(500) }).parse(request.body);
    const state = await readState();
    const token = state.tokens.user ?? state.tokens.app;
    if (token && state.config.channelId) {
      await api.sendChatMessage(token.accessToken, {
        channelId: state.config.channelId,
        message: body.message,
        ...token.type === "app" && state.config.botUserId ? { senderId: state.config.botUserId } : {}
      });
    }
    await addEvent({
      id: nanoid5(),
      type: "reply",
      title: "Manual bot message",
      detail: body.message,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});
app.post("/api/review/:id/resolve", async (request, response) => {
  const state = await writeState((draft) => {
    const item = draft.reviewQueue.find((entry) => entry.id === request.params.id);
    if (item) {
      item.status = "resolved";
      item.resolvedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
  });
  response.json(state.reviewQueue.find((item) => item.id === request.params.id));
});
app.post("/api/giveaways", async (request, response) => {
  const body = z.object({
    title: z.string().min(1).max(100).default("Chat Giveaway"),
    prize: z.string().min(1).max(160).default("Stream prize"),
    entryPhrase: z.string().min(1).max(80).default("!enter"),
    subscriberMultiplier: z.number().int().min(1).max(10).default(2)
  }).parse(request.body);
  const giveaway = createGiveawayRecord(body, await readState());
  const state = await writeState((draft) => {
    draft.giveaways.unshift(giveaway);
    draft.giveaways = draft.giveaways.slice(0, 80);
    draft.events.unshift({
      id: nanoid5(),
      type: "game",
      title: "Giveaway created",
      detail: `${giveaway.title} is ready. Viewers enter with "${giveaway.entryPhrase}".`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
  response.json(state.giveaways);
});
app.post("/api/giveaways/:id/open", async (request, response, next) => {
  let openedGiveaway;
  const state = await writeState((draft) => {
    const giveaway = draft.giveaways.find((item) => item.id === request.params.id);
    if (giveaway && giveaway.status === "draft") {
      giveaway.status = "open";
      giveaway.openedAt = (/* @__PURE__ */ new Date()).toISOString();
      openedGiveaway = giveaway;
      draft.events.unshift({
        id: nanoid5(),
        type: "game",
        title: "Giveaway launched",
        detail: `${giveaway.title} launched. Viewers enter with "${giveaway.entryPhrase}".`,
        createdAt: giveaway.openedAt
      });
      draft.events = draft.events.slice(0, 80);
    }
  });
  try {
    if (openedGiveaway) await sendGiveawayChatMessage(openedGiveaway, state, "open");
    response.json(state.giveaways.find((item) => item.id === request.params.id));
  } catch (error) {
    next(error);
  }
});
app.post("/api/giveaways/:id/enter", async (request, response) => {
  const body = z.object({
    userId: z.string().min(1).max(120),
    username: z.string().min(1).max(80),
    displayName: z.string().min(1).max(80),
    avatarUrl: z.string().url().optional(),
    isSubscriber: z.boolean().default(false)
  }).parse(request.body);
  const current = await readState();
  const giveaway = current.giveaways.find((item) => item.id === request.params.id);
  const entry = {
    ...body,
    weight: body.isSubscriber ? Math.max(1, giveaway?.subscriberMultiplier ?? 2) : 1,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  const state = await writeState((draft) => {
    const giveaway2 = draft.giveaways.find((item) => item.id === request.params.id);
    if (giveaway2 && giveaway2.status === "open" && !giveaway2.entries.some((item) => item.userId === entry.userId)) {
      giveaway2.entries.push(entry);
    }
  });
  response.json(state.giveaways.find((item) => item.id === request.params.id));
});
app.post("/api/giveaways/:id/close", async (request, response, next) => {
  let closedGiveaway;
  const state = await writeState((draft) => {
    const giveaway = draft.giveaways.find((item) => item.id === request.params.id);
    if (giveaway && giveaway.status === "open") {
      giveaway.status = "closed";
      giveaway.closedAt = (/* @__PURE__ */ new Date()).toISOString();
      giveaway.winner = pickWeightedWinner(giveaway.entries);
      closedGiveaway = giveaway;
      draft.events.unshift({
        id: nanoid5(),
        type: "game",
        title: "Giveaway closed",
        detail: giveaway.winner ? `${giveaway.winner.displayName} won ${giveaway.prize}.` : `${giveaway.title} closed with no entries.`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      draft.events = draft.events.slice(0, 80);
    }
  });
  try {
    if (closedGiveaway) await sendGiveawayChatMessage(closedGiveaway, state, "close");
    response.json(state.giveaways.find((item) => item.id === request.params.id));
  } catch (error) {
    next(error);
  }
});
app.delete("/api/giveaways/:id", async (request, response) => {
  const current = await readState();
  const giveaway = current.giveaways.find((item) => item.id === request.params.id);
  if (giveaway?.status === "open") {
    response.status(409).json({ error: "Close the live raffle before removing it." });
    return;
  }
  const state = await writeState((draft) => {
    draft.giveaways = draft.giveaways.filter((item) => item.id !== request.params.id);
  });
  response.json(state.giveaways);
});
app.patch("/api/collection/:name/:id", async (request, response) => {
  const collectionName = request.params.name;
  const allowed = ["commands", "timers", "games", "rewards"];
  if (!allowed.includes(collectionName)) {
    response.status(404).json({ error: "Unknown collection." });
    return;
  }
  const current = await readState();
  const collection = current[collectionName];
  const existing = collection.find((entry) => entry.id === request.params.id);
  const touchesPro = Boolean(existing?.proOnly || request.body?.proOnly);
  if (touchesPro && !hasProAccess(current.billing)) {
    response.status(402).json({ error: "This is a Pro feature. Upgrade or redeem an eligible FRAGBOT subscriber trial." });
    return;
  }
  const state = await writeState((draft) => {
    const draftCollection = draft[collectionName];
    const item = draftCollection.find((entry) => entry.id === request.params.id);
    if (item) Object.assign(item, request.body);
  });
  response.json(state[collectionName]);
});
app.post("/api/collection/:name", async (request, response) => {
  const collectionName = request.params.name;
  const allowed = ["commands", "timers", "games", "rewards"];
  if (!allowed.includes(collectionName)) {
    response.status(404).json({ error: "Unknown collection." });
    return;
  }
  const current = await readState();
  if (request.body?.proOnly && !hasProAccess(current.billing)) {
    response.status(402).json({ error: "Pro-only items require an active Pro subscription or eligible trial." });
    return;
  }
  const state = await writeState((draft) => {
    const collection = draft[collectionName];
    collection.unshift({ id: nanoid5(), enabled: true, ...request.body });
  });
  response.json(state[collectionName]);
});
app.delete("/api/collection/:name/:id", async (request, response) => {
  const collectionName = request.params.name;
  const allowed = ["commands", "timers", "games", "rewards"];
  if (!allowed.includes(collectionName)) {
    response.status(404).json({ error: "Unknown collection." });
    return;
  }
  const state = await writeState((draft) => {
    const collection = draft[collectionName];
    const index = collection.findIndex((entry) => entry.id === request.params.id);
    if (index >= 0) collection.splice(index, 1);
  });
  response.json(state[collectionName]);
});
var __dirname = path2.dirname(fileURLToPath(import.meta.url));
var distPath = path2.resolve(__dirname, "..", "dist");
app.use(express.static(distPath));
app.get("*", (_request, response) => {
  response.sendFile(path2.join(distPath, "index.html"));
});
app.use((error, _request, response, _next) => {
  if (error instanceof BlazeApiError) {
    const payload = error.payload;
    const message = payload?.message && !error.message.includes(payload.message) ? `${error.message}: ${payload.message}` : error.message;
    response.status(error.status || 500).json({ error: message, details: error.payload });
    return;
  }
  if (error instanceof z.ZodError) {
    response.status(400).json({ error: "Invalid request body.", details: error.flatten() });
    return;
  }
  response.status(500).json({ error: error instanceof Error ? error.message : "Unknown server error." });
});
app.listen(env.port, env.host, () => {
  console.log(`FRAGBOT API listening on http://${env.host}:${env.port}`);
});
async function generateBlazeAuthUrl(_purpose) {
  const scopes = ["users.read", "offline.access", "channel.moderate"];
  const candidates = getRedirectCandidates();
  for (const redirectUri of candidates) {
    try {
      const result = await api.generateAuthUrl(scopes, redirectUri);
      return { ...result, redirectUri };
    } catch (error) {
      if (isInvalidRedirectError(error)) continue;
      throw error;
    }
  }
  throw new BlazeApiError(
    `Blaze rejected the OAuth callback URL. Add ${candidates[0]} to the Blaze app's allowed redirect URIs, then try Connect Blaze account again.`,
    400,
    {
      success: false,
      message: "invalid redirect_uri",
      redirectUrisTried: candidates
    }
  );
}
function getRedirectCandidates() {
  return Array.from(
    /* @__PURE__ */ new Set([
      env.blazeRedirectUri,
      "https://fragbot.tech/api/blaze/callback",
      `http://127.0.0.1:${env.port}/api/blaze/callback`,
      `http://localhost:${env.port}/api/blaze/callback`
    ])
  ).filter(Boolean);
}
function isInvalidRedirectError(error) {
  if (!(error instanceof BlazeApiError)) return false;
  const payload = error.payload;
  return error.status === 400 && payload?.message === "invalid redirect_uri";
}
async function handleStripeEvent(event) {
  switch (event.type) {
    case "checkout.session.completed":
      await applyCheckoutSession(event.data.object);
      break;
    case "customer.subscription.updated":
    case "customer.subscription.deleted":
      await applySubscription(event.data.object);
      break;
    default:
      break;
  }
}
async function applyCheckoutSession(session) {
  if (!stripe || session.mode !== "subscription") return;
  const subscription = typeof session.subscription === "string" ? await stripe.subscriptions.retrieve(session.subscription) : session.subscription;
  const customerId = typeof session.customer === "string" ? session.customer : session.customer?.id;
  await writeState((draft) => {
    draft.billing.status = "pro";
    draft.billing.stripeCustomerId = customerId ?? draft.billing.stripeCustomerId;
    draft.billing.stripeSubscriptionId = subscription?.id ?? draft.billing.stripeSubscriptionId;
    draft.billing.stripeCheckoutSessionId = session.id;
    draft.billing.stripeSubscriptionStatus = subscription?.status ?? "active";
    draft.billing.paidUntil = periodEndToIso(subscription);
    draft.config.plan = "pro";
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title: "Stripe Pro activated",
      detail: "$9.99/mo subscription confirmed. Pro features are unlocked.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
}
async function applySubscription(subscription) {
  const customerId = typeof subscription.customer === "string" ? subscription.customer : subscription.customer?.id;
  const active = subscription.status === "active" || subscription.status === "trialing";
  await writeState((draft) => {
    if (draft.billing.stripeSubscriptionId && draft.billing.stripeSubscriptionId !== subscription.id && draft.billing.stripeCustomerId && draft.billing.stripeCustomerId !== customerId) {
      return;
    }
    draft.billing.stripeCustomerId = customerId ?? draft.billing.stripeCustomerId;
    draft.billing.stripeSubscriptionId = subscription.id;
    draft.billing.stripeSubscriptionStatus = subscription.status;
    draft.billing.paidUntil = periodEndToIso(subscription);
    draft.billing.status = active ? "pro" : "free";
    draft.config.plan = active ? "pro" : "free";
    if (!active && draft.config.mode === "autopilot") draft.config.mode = "assist";
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title: active ? "Stripe subscription active" : "Stripe subscription inactive",
      detail: `Subscription status changed to ${subscription.status}.`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
}
function periodEndToIso(subscription) {
  const currentPeriodEnd = subscription?.current_period_end;
  return currentPeriodEnd ? new Date(currentPeriodEnd * 1e3).toISOString() : void 0;
}
async function recordBillingEvent(title, detail) {
  await writeState((draft) => {
    draft.billing.lastCheckoutAttemptAt = (/* @__PURE__ */ new Date()).toISOString();
    draft.events.unshift({
      id: nanoid5(),
      type: "system",
      title,
      detail,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    draft.events = draft.events.slice(0, 80);
  });
}
function getStripeClientReference(state) {
  return state.streamer.userId || state.streamer.channelId || state.streamer.userSlug || state.streamer.email || "local-fragbot-streamer";
}
function buildStripePaymentLinkUrl(baseUrl, state) {
  try {
    const url = new URL(baseUrl);
    url.searchParams.set("client_reference_id", getStripeClientReference(state));
    if (state.streamer.email.includes("@")) {
      url.searchParams.set("prefilled_email", state.streamer.email);
    }
    return url.toString();
  } catch {
    return baseUrl;
  }
}
function buildDashboardSnapshot(state) {
  const entitlements = createEntitlements(state.billing);
  return {
    config: {
      ...state.config,
      plan: entitlements.proAccess ? "pro" : "free",
      mode: entitlements.proAccess || state.config.mode !== "autopilot" ? state.config.mode : "assist"
    },
    billing: state.billing,
    streamer: state.streamer,
    entitlements,
    commands: state.commands,
    timers: state.timers,
    games: state.games,
    rewards: state.rewards,
    giveaways: state.giveaways,
    loyalty: state.loyalty.slice(0, 20),
    reviewQueue: state.reviewQueue,
    events: state.events,
    analytics: state.analytics,
    connection: {
      ...safeConnectionStatus(eventService.isRunning()),
      hasUserToken: Boolean(state.tokens.user),
      hasAppToken: Boolean(state.tokens.app),
      botAccountSlug: env.blazeBotAccount
    },
    plans: [
      {
        name: "free",
        price: "$0",
        limits: ["1 channel", "10 commands", "2 timers", "basic loyalty"],
        features: ["Editable basic commands", "Safety review queue", "Lucky Roll game", "Manual FRAGBOT messages"]
      },
      {
        name: "pro",
        price: "$9.99/mo",
        limits: ["multi-channel ready", "unlimited commands", "advanced timers", "full loyalty economy"],
        features: ["Autopilot moderation", "AI chat personality", "Advanced games and overlay rewards", "Priority event automation"]
      }
    ]
  };
}
function createEntitlements(billing) {
  const proAccess = hasProAccess(billing);
  return {
    proAccess,
    proReason: getProReason(billing, proAccess),
    trialEligible: billing.cptfiveSubscriberMonths >= 3 && !billing.trialRedeemed,
    lockedFeatures: proAccess ? [] : ["Autopilot moderation", "Pro-only commands", "Advanced timers", "Advanced games", "Overlay rewards", "Expanded loyalty economy"]
  };
}
function hasProAccess(billing) {
  if (billing.status === "pro") return !billing.paidUntil || isFutureDate(billing.paidUntil);
  if (billing.status === "trial") return isFutureDate(billing.trialEndsAt);
  return false;
}
function derivePlan(billing) {
  return hasProAccess(billing) ? "pro" : "free";
}
function getProReason(billing, proAccess) {
  if (billing.status === "trial" && proAccess && billing.trialEndsAt) {
    return `cptfive subscriber trial active until ${formatDate(billing.trialEndsAt)}.`;
  }
  if (billing.status === "pro" && proAccess) {
    return billing.paidUntil ? `Paid Pro active until ${formatDate(billing.paidUntil)}.` : "Paid Pro is active.";
  }
  if (billing.trialRedeemed && billing.status === "trial") return "cptfive subscriber trial expired.";
  if (billing.cptfiveSubscriberMonths >= 3 && !billing.trialRedeemed) return "Eligible for a 30 day Pro trial from logged-in Blaze subscriptions.";
  return "Pro is locked until payment is active or a 3 month cptfive subscriber trial is redeemed.";
}
function isFutureDate(value) {
  return Boolean(value && new Date(value).getTime() > Date.now());
}
function formatDate(value) {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(new Date(value));
}
function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}
async function syncStreamerIdentity(token) {
  const profile = await api.getUserProfile(token.accessToken);
  const user = profile.data;
  const userId = user.userId ?? user.id ?? token.userId ?? "";
  const userSlug = user.slug ?? user.username ?? "";
  const displayName = user.displayName || userSlug;
  const channels = userSlug ? await api.listChannels(token.accessToken, userSlug).catch(() => void 0) : void 0;
  const channel = channels?.data.rows[0];
  const channelId = channel?.id ?? userId;
  const channelSlug = channel?.slug ?? userSlug;
  const state = await writeState((draft) => {
    draft.streamer = {
      ...draft.streamer,
      loggedIn: true,
      blazeConnected: true,
      email: user.username || userSlug || draft.streamer.email,
      userId,
      username: userSlug,
      userSlug,
      displayName,
      avatarUrl: user.avatarUrl ?? channel?.avatarUrl ?? "",
      channelId,
      channelSlug,
      botAdded: true,
      createdAt: draft.streamer.createdAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    draft.config.channelId = channelId;
  });
  return state.streamer;
}
async function getCptfiveSubscriberMonths(token) {
  const state = await readState();
  const streamer = state.streamer.userId ? state.streamer : await syncStreamerIdentity(token);
  if (!streamer.userId && !token.userId) {
    throw new Error("The signed-in Blaze user UUID is missing. Reconnect the streamer's Blaze account.");
  }
  const [subscriptions, cptfiveChannel] = await Promise.all([
    api.listUserSubscriptions(token.accessToken),
    api.listChannels(token.accessToken, "cptfive").catch(() => void 0)
  ]);
  const cptfiveChannelId = cptfiveChannel?.data.rows[0]?.id;
  const activeRows = [...subscriptions.data.active, ...subscriptions.data.gifted];
  const match = activeRows.find((row) => {
    const displayName = normalizeSlug(row.displayName ?? "");
    return cptfiveChannelId && row.channelId === cptfiveChannelId || displayName === "cptfive";
  });
  if (!match) return 0;
  return Math.max(match.renewCount ?? 0, match.streakCount ?? 0, monthsSince(match.subscribedAt), match.expiresAt ? 1 : 0);
}
function monthsSince(value) {
  if (!value) return 0;
  const startedAt = new Date(value).getTime();
  if (!Number.isFinite(startedAt)) return 0;
  const days = (Date.now() - startedAt) / 864e5;
  return Math.max(0, Math.floor(days / 30));
}
function normalizeSlug(value) {
  return value.trim().replace(/^@/, "").toLowerCase();
}
function createGiveawayRecord(body, state) {
  return {
    id: nanoid5(),
    channelId: state.streamer.channelId || state.config.channelId || "unassigned-channel",
    channelSlug: state.streamer.channelSlug || "unassigned",
    title: body.title,
    prize: body.prize,
    entryPhrase: normalizeEntryPhrase(body.entryPhrase),
    subscriberMultiplier: body.subscriberMultiplier,
    source: "manual",
    status: "draft",
    entries: [],
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function recordGiveawayEntries(message) {
  if (message.sender.isBot) return [];
  const normalizedMessage = normalizeEntryPhraseForMatch(message.message);
  const entries = [];
  await writeState((draft) => {
    for (const giveaway of draft.giveaways) {
      if (giveaway.status !== "open") continue;
      if (normalizeEntryPhraseForMatch(giveaway.entryPhrase) !== normalizedMessage) continue;
      if (giveaway.entries.some((entry2) => entry2.userId === message.sender.id)) continue;
      const entry = {
        userId: message.sender.id,
        username: message.sender.username,
        displayName: message.sender.displayName,
        avatarUrl: message.sender.avatarUrl,
        isSubscriber: Boolean(message.sender.isSubscriber),
        weight: message.sender.isSubscriber ? Math.max(1, giveaway.subscriberMultiplier) : 1,
        createdAt: message.createdAt
      };
      giveaway.entries.push(entry);
      entries.push({ giveawayId: giveaway.id, entry });
    }
  });
  return entries;
}
function normalizeEntryPhrase(value) {
  return value.trim().replace(/\s+/g, " ");
}
function normalizeEntryPhraseForMatch(value) {
  return normalizeEntryPhrase(value).toLowerCase();
}
function pickWeightedWinner(entries) {
  const weightedPool = entries.flatMap((entry) => Array.from({ length: Math.max(1, entry.weight) }, () => entry));
  if (!weightedPool.length) return void 0;
  return weightedPool[Math.floor(Math.random() * weightedPool.length)];
}
async function sendGiveawayChatMessage(giveaway, state, phase) {
  const token = state.tokens.user ?? state.tokens.app;
  const channelId = state.config.channelId || giveaway.channelId;
  if (!token || !channelId) return;
  const senderId = token.type === "app" && state.config.botUserId ? { senderId: state.config.botUserId } : {};
  const message = phase === "open" ? `FRAGBOT giveaway is live: ${giveaway.title}. Prize: ${giveaway.prize}. Type "${giveaway.entryPhrase}" to enter. Subscribers get x${giveaway.subscriberMultiplier} chance.` : giveaway.winner ? `FRAGBOT giveaway closed. Winner: ${giveaway.winner.displayName}. Prize: ${giveaway.prize}.` : `FRAGBOT giveaway closed. No entries were recorded for ${giveaway.title}.`;
  await api.sendChatMessage(token.accessToken, {
    channelId,
    message: message.slice(0, 500),
    ...senderId
  }).catch(() => void 0);
}
async function executeBlazeActions(message, decision) {
  const state = await readState();
  const token = state.tokens.user ?? state.tokens.app;
  const canSendLive = Boolean(token && state.config.channelId);
  const senderId = token?.type === "app" && state.config.botUserId ? { senderId: state.config.botUserId } : {};
  if (decision.reply && decision.actions.includes("reply")) {
    if (canSendLive && token) {
      await api.sendChatMessage(token.accessToken, {
        channelId: state.config.channelId,
        message: decision.reply.slice(0, 500),
        replyToMessageId: message.messageId,
        ...senderId
      }).catch(() => void 0);
    }
  }
  if (state.config.mode !== "autopilot" || !hasProAccess(state.billing) || !token || !state.config.channelId) return;
  if (decision.actions.includes("delete")) {
    await api.deleteChatMessage(token.accessToken, {
      channelId: state.config.channelId,
      messageId: message.messageId,
      ...senderId
    }).catch(() => void 0);
  }
  if (decision.actions.includes("mute")) {
    await api.muteUser(token.accessToken, {
      channelId: state.config.channelId,
      mutedUserId: message.sender.id,
      ...senderId
    }).catch(() => void 0);
  }
  if (decision.actions.includes("ban")) {
    await api.banUser(token.accessToken, {
      channelId: state.config.channelId,
      banUserId: message.sender.id,
      ...senderId
    }).catch(() => void 0);
  }
}
function summarizePayload(payload) {
  const displayName = payload.sender?.displayName ?? payload.follower?.displayName ?? payload.subscriber?.displayName ?? payload.raider?.displayName;
  if (displayName) return `${displayName} triggered an event.`;
  return JSON.stringify(payload).slice(0, 220);
}
