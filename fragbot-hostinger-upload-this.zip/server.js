﻿import express from "express";

void express;
process.env.HOST ||= "0.0.0.0";
process.env.PORT ||= "3000";

await import("./server/index.js");
